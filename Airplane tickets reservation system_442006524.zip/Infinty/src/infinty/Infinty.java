/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infinty;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


/**
 *
 * @author USER
 */
public class Infinty {

    /**
     * @param args the command line arguments
     */ 
    
    public static String Name;
    public static String Address;
    public static ArrayList<Flight> AllFlifht;
    public static int phone;

    public static void main(String[] args) {

        AllFlifht = new ArrayList<Flight>();
        Flight f = new Flight(102, "Jeddah ", "1:20 pm", "1-1-1442", "Riyadh", "2:10 pm", "1-1-1442");
        f.addTicket(new EconomicTicket("Economic", 450));
        f.addTicket(new BusinessTicket("Business", 1500));
        f.addTicket(new FirstClassTicket("FirstClass", 600));
        Flight f2 = new Flight(103, "Jeddah ", "1:30 pm", "1-1-1442", "Riyadh", "2:20 pm", "1-1-1442");
        f2.addTicket(new EconomicTicket("Economic", 120));
        f2.addTicket(new BusinessTicket("Business", 500));
        f2.addTicket(new FirstClassTicket("FirstClass", 250));
        Flight f3 = new Flight(104, "Riyadh ", "10:50 pm", "3-1-1442", "Jeddah", "11:40 pm", "1-1-1442");
        f3.addTicket(new EconomicTicket("Economic", 120));
        f3.addTicket(new BusinessTicket("Business", 500));
        f3.addTicket(new FirstClassTicket("FirstClass", 250));
        AllFlifht.add(f);
        AllFlifht.add(f2);
        AllFlifht.add(f3);

        // TODO code application logic here
        Name = "Infinty";
        Address = "Makkah";
        phone = 57124567;
        System.out.println("Dear customer Welcome to on Airplane tickets reservation system");
        // login
        Scanner in = new Scanner(System.in);
        System.out.print(
                "1. A password must have at least eight characters.\n"
                + "2. A password consists of only letters and digits.\n"
                + "3. A password must contain at least two digits \n"
                + "Input a password (You are agreeing to the above Terms and Conditions): ");
        String pass = in.nextLine();
        System.out.println("enter user");
        String uu = in.nextLine();
        User u = new User(uu);
        
        while (u.Check(pass) != true) {
            System.out.println("Not a valid password: " + pass);
            System.out.println("try again");
            pass = in.nextLine();
        }

        System.out.println("Password is valid: " + pass);
                System.out.println("*********************************************************");
        System.out.println("your username: "+uu+"\n"+"your password: "+pass);
        System.out.println("welcome to "+Name);
        System.out.println("*********************************************************");
        Passenger p = new Passenger();
      Ticket passticketseat=new EconomicTicket();
        int choice = 0;
        while (choice != 10) {
            System.out.println("These options will be repeated for you several times to book more than one ticket\n (so choose a number each time)");
            System.out.println("1- reserve flight\n2-Calculate total price\n3-print ticket \n 4- exit");
                    System.out.println("*********************************************************");
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("We'll show you available flights");
                    for (int i = 0; i < AllFlifht.size(); i++) {
                        System.out.println((i+1)+"= "+AllFlifht.get(i) + " ");
                       
                    }
                    System.out.println("Please enter your choice\n1-flight 1 2-flight 2- 3-flights3");
                    int fl= in.nextInt();
                    AllFlifht.get(fl-1).displayticket();
                    System.out.println("Please enter your Ticket\n1-Economic 2-Business 3-first");
                    int ti= in.nextInt();
                     Ticket passticket=AllFlifht.get(fl-1).getTicket(ti-1);

                    int i, j, seatNum, c = 0;
        char seatLetter = 'A';
         int choice3 = 0;
        String seatEnter;
        boolean flag = true; // loops of running the program
//        while (choice3 != 3 && flag) {

            System.out.println(" Assign Seats \n Note: It will not be booked into our system because it will come at the time of boarding\n (we only show you the seats you can see at that time so you know about them)" );
          
            System.out.println("Select your choice: ");

//            choice3 = in.nextInt();
            int numOfreservation = 0;

//            switch (choice3) {
//                case 6:
                    System.out.println("How many seats do you want to book ?");
                    numOfreservation = in.nextInt();
                    //Set the value.
                    for (i = 0; i < passticketseat.SeatNumber.length; i++) {
                        for (j = 0; j < passticketseat.SeatNumber[i].length; j++) {
                            passticketseat.SeatNumber[i][j] = seatLetter++;
                        }
                        seatLetter = 'A'; // to reset the value to A for the new loop
                    }

                    //To display the list of seats
                    for (i = 0; i < passticketseat.SeatNumber.length; i++) {
                        System.out.print((i + 1) + " ");
                        for (j = 0; j < passticketseat.SeatNumber[i].length; j++) {
                            System.out.print(passticketseat.SeatNumber[i][j] + " ");
                        }
                        System.out.println();
                    }

                   //condition
                    while (c < numOfreservation) {
                        do {
                            System.out.print("Please type the chosen seat(start with row and column, e.g:2B): ");

                            seatEnter = (in.next()).toUpperCase(); //covert to Upper case
                            seatNum = Integer.parseInt(seatEnter.charAt(0) + ""); //converts a String to an int

                            if (seatNum != 0) {
                                seatLetter = seatEnter.charAt(1);
                            }
                            i++;
                            //if user enters wrong input, error message will appear.
                            if (seatLetter != 'A') {
                                if (seatLetter != 'B') {
                                    if (seatLetter != 'C') {
                                        if (seatLetter != 'D') {
                                            if (seatLetter != 'E') {
                                                System.out.println("Invalid! Please enter the correct seat: ");
                                            }
                                        }
                                    }
                                }
                            }

                        } //continue to loop until the condition true
                        while (seatNum < 0 || seatNum > 7 || seatLetter < 'A' || seatLetter > 'E');

                        if (seatNum == 0) {
                            flag = false;
                        } else {
                            if (passticketseat.SeatNumber[seatNum - 1][seatLetter - 65] == 'X') {
                                System.out.println("\n       ******Seat have been taken******.\n           Please choose another seat:\n");
                            } else {
                                passticketseat.SeatNumber[seatNum - 1][seatLetter - 65] = 'X';
                            }
                        }
                        // To display updated lists of seats
                        for (i = 0; i <passticketseat.SeatNumber.length; i++) {
                            System.out.print((i + 1) + " ");
                            for (j = 0; j < passticketseat.SeatNumber[i].length; j++) {
                                System.out.print(passticketseat.SeatNumber[i][j] + " ");
                            }
                            System.out.println();
                        }
                        System.out.println();
                          c++; 
                    }
                    if (c == 20) {
                        System.out.println("All seats are now fully-booked.");
                    }
                     System.out.println("Dear passenger, please enter your personal information\n enter your First name ");

                     String Firstname=in.next();
                     p.setFirstName(Firstname);
                     System.out.println("________________________________________________");
                     System.out.println("enter your Last name ");

                     String Lastname=in.next();
                     p.setLastName(Lastname);
                              System.out.println("________________________________________________");

                     System.out.println("enter your gender ( please write Female or  male) ");
                      String Gender=in.next();
                     p.setGender(Gender);
                       System.out.println("________________________________________________");

                     System.out.println("enter your Age ( please write as number ");
                      int Age=in.nextInt();
                         System.out.println("________________________________________________");

                      p.setAge(Age);
                    System.out.println("enter your Passportnumber ( please write as number )");
                     int Passportnumber=in.nextInt();
                     p.setPassportNum(Passportnumber);  
                     System.out.println("________________________________________________");

//        // Initialization
////           int id=(int)Math.random()*(100-1)+1;
//                   int d=10;
                p.reservTicket(passticket.clone(p.NumID,AllFlifht.get(fl-1)));
                    break;
                case 2:
                  System.out.println("________________________________________________");

                    System.out.println("Total Price :"+p.GetSeatPrice());
                    break;
                case 3:
                     System.out.println(p);
              System.out.println("Booked by " + Name + "\n" + "Telephone: " + phone + "\n" + "Address: " + Address);

                    break;
                case 4:
                    System.exit(0);
                    break;
             
            }

        }}}



