/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infinty;
import java.util.Random;

/**
 *
 * @author USER
 */
/*this class is subclass from Ticket and Each ticket will have its own category and each category has a different price for each flight so in this class 
we Override method GetSeatPrice and clone also to string 
*/
public class BusinessTicket extends Ticket {
public String SeatType;
 public double Price;
    public BusinessTicket() {
          
    }
    
    public BusinessTicket(String SeatType,double Price ){
        super.SeatNumber=SeatNumber;
    this.SeatType="Business";
    this.Price=Price;
    }
   
    public BusinessTicket(int NumID, Flight DetailsFlight, Passenger PassengDetails) {
        super( NumID,DetailsFlight, PassengDetails);
    }

   @Override 
       public double GetSeatPrice(){

         return Price ;
       }
public  Ticket clone (Ticket id ,Flight F){
 Ticket t= new BusinessTicket(SeatType , Price);
  t.DetailsFlight=F;
 t.NumID=(int)(Math.random()*(101));
 
 return t;
 }

    @Override
    public String toString() {
        return  "SeatType is : " + SeatType +","+" Price ="+Price ;
    }
    
}
